

import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item>
{
	private static final int INIT_SIZE = 4;

	private Item[] elements;
	private int size;

	@SuppressWarnings("unchecked")
	public RandomizedQueue()
	{
		elements = (Item[]) new Object[INIT_SIZE];
		size = 0;
	}

	public boolean isEmpty()
	{
		return size == 0;
	}

	public int size()
	{
		return size;
	}

	public void enqueue(Item item)
	{
		checkNull(item);
		if (isFull())
			resize(2 * elements.length);

		elements[size++] = item;
	}

	public Item dequeue()
	{
		checkEmpty();
		int randIndex = StdRandom.uniform(size);
		Item item = elements[randIndex];

		// exchange the last element with randIndex
		elements[randIndex] = elements[--size];
		elements[size] = null;

		if (size > 0 && size == elements.length / 4)
			resize(elements.length / 2);
		return item;
	}

	public Item sample()
	{
		checkEmpty();
		return elements[StdRandom.uniform(size)];
	}

	@Override
	public Iterator<Item> iterator()
	{
		return new ListIterator<>(elements);
	}

	@SuppressWarnings("hiding")
	private class ListIterator<Item> implements Iterator<Item>
	{
		private Item[] arr;
		private int index;

		@SuppressWarnings("unchecked")
		public ListIterator(Object[] elements)
		{
			arr = (Item[]) new Object[size];
			index = 0;
			for (int i = 0; i < size; i++)
			{
				arr[i] = (Item) elements[i];
			}
			shuffle(arr);
		}

		@Override
		public boolean hasNext()
		{
			return index != size;
		}

		@Override
		public Item next()
		{
			if (!hasNext())
			{
				throw new NoSuchElementException();
			}
			return arr[index++];
		}

		private void shuffle(Item[] arr)
		{
			for (int i = arr.length - 1; i > 0; i--)
			{
				int temp = StdRandom.uniform(i);
				swap(arr, temp, i);
			}
		}

		private void swap(Item[] arr, int i, int j)
		{
			Item temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}

	}

	private void resize(int len)
	{
		@SuppressWarnings("unchecked")
		Item[] temp = (Item[]) new Object[len];
		for (int i = 0; i < size; i++)
		{
			temp[i] = elements[i];
		}
		elements = temp;
	}

	private void checkNull(Item item)
	{
		if (item.equals(null))
		{
			throw new NullPointerException();
		}
	}

	private void checkEmpty()
	{
		if (isEmpty())
		{
			throw new NoSuchElementException();
		}
	}

	private boolean isFull()
	{
		return size == elements.length;
	}

	@Override
	public String toString()
	{
		String res = "";
		for (int i = 0; i < size; i++)
		{
			res += elements[i] + " ";
		}
		return res.trim();
	}

	public static void main(String[] args)
	{
		RandomizedQueue<Integer> randq = new RandomizedQueue<>();
		for (int i = 0; i < 10; i++)
		{
			randq.enqueue(i);
		}
		System.out.println(randq.size());
		System.out.println(randq);

		int n = 5;
		while (n-- != 0)
		{
			System.out.print(randq.dequeue() + " ");
		}

		Iterator<Integer> it = randq.iterator();
		System.out.println();
		while (it.hasNext())
		{
			System.out.print(it.next() + " ");
		}

	}
}
