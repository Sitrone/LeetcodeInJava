

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item>
{
	private Node<Item> first;
	private Node<Item> last;
	private int size;

	public Deque()
	{
		this.first = null;
		this.last = null;
		this.size = 0;
	}

	public boolean isEmpty()
	{
		return size == 0;
	}

	public int size()
	{
		return size;
	}

	public void addFirst(Item item)
	{
		checkNull(item);
		Node<Item> oldFirst = first;
		first = new Node<Item>(item, oldFirst);
		if (isEmpty())
			last = first;
		size++;
	}

	public void addLast(Item item)
	{
		checkNull(item);
		Node<Item> oldLast = last;
		last = new Node<Item>(item, null);
		if (isEmpty())
			first = last;
		else
			oldLast.next = last;
		size++;
	}

	public Item removeFirst()
	{
		checkEmpty();
		Item item = first.item;
		first = first.next;
		size--;
		if (isEmpty())
			last = null;
		return item;
	}

	public Item removeLast()
	{
		checkEmpty();
		Item item = last.item;
		Node<Item> cur = first;
		while (cur.next != null && cur.next.next != null)
		{
			cur = cur.next;
		}
		if (last == cur)
		{
			first = last = null;
		}
		else
		{
			last = cur;
			cur.next = null;
		}
		size--;
		return item;
	}

	@Override
	public Iterator<Item> iterator()
	{
		return new DequeIterator<Item>(first);
	}

	@Override
	public String toString()
	{
		String res = "";
		Iterator<Item> it = iterator();
		while (it.hasNext())
		{
			res += it.next() + " ";
		}
		return res.trim();
	}

	private void checkNull(Item item)
	{
		if (item == null)
		{
			throw new NullPointerException();
		}
	}

	private void checkEmpty()
	{
		if (isEmpty())
		{
			throw new NoSuchElementException();
		}
	}

	@SuppressWarnings("hiding")
	private class DequeIterator<Item> implements Iterator<Item>
	{
		private Node<Item> cur;

		public DequeIterator(Node<Item> first)
		{
			this.cur = first;
		}

		@Override
		public boolean hasNext()
		{
			return cur != null;
		}

		@Override
		public Item next()
		{
			if (!hasNext())
				throw new NoSuchElementException();
			Item item = cur.item;
			cur = cur.next;
			return item;
		}

		public void remove()
		{
			throw new UnsupportedOperationException();
		}

	}

	private static class Node<Item>
	{
		Item item;
		Node<Item> next;

		public Node(Item item, Node<Item> next)
		{
			this.item = item;
			this.next = next;
		}
	}

	public static void main(String[] args)
	{
		Deque<Integer> deque = new Deque<>();
		// deque.addFirst(0);
		// deque.removeLast(); //==> 0
		//// deque.removeFirst();
		// deque.addFirst(2);
		// deque.isEmpty();
		// deque.removeLast(); // ==> 2
		// deque.isEmpty();
		// deque.addFirst(6);
		// deque.addFirst(7);
		// deque.removeLast(); //==> 6
		// deque.addFirst(9);
		// deque.removeLast() ; //==> 6
		for (int i = 0; i < 20; i++)
		{
			deque.addLast(i);
		}
		System.out.println(deque);
		int n = 5;
		while (n-- != 0)
		{
			System.out.println(deque.removeFirst());
		}
		System.out.println(deque);
		for (int i = 0; i < 6; i++)
		{
			deque.addFirst(i);
		}
		System.out.println(deque);
		n = 5;
		while (n-- != 0)
		{
			System.out.println(deque.removeLast());
		}
		System.out.println(deque);
	}
}
